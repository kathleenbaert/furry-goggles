﻿using System;

namespace LabAvailability
{
	public static class Constants
	{
		// Replace strings with your Azure Mobile App endpoint.
		public static string ApplicationURL = @"https://labavailability.azurewebsites.net";
	}
}

